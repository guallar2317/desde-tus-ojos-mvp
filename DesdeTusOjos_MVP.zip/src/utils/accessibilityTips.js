export const tips = [
  "Usa botones grandes con buen contraste.",
  "Evita el uso exclusivo del color para transmitir información.",
  "Incluye texto alternativo en las imágenes.",
];
